(function () {
  let password = document.querySelector(".password");

  let TextoAjuda = {
    charTamanho: document.querySelector(".texto-ajuda .tamanho"),
    minusculo: document.querySelector(".texto-ajuda .minusculo"),
    maiusculo: document.querySelector(".texto-ajuda .maiusculo"),
    numero: document.querySelector(".texto-ajuda .numero"),
    especial: document.querySelector(".texto-ajuda .especial")
  };

  let pattern = {
    charTamanho: function () {
      if (password.value.length >= 8) {
        return true;
      }
    },
    minusculo: function () {
      let regex = /^(?=.*[a-z]).+$/; // Padrão de caracteres minúsculos

      if (regex.test(password.value)) {
        return true;
      }
    },
    maiusculo: function () {
      let regex = /^(?=.*[A-Z]).+$/; // Padrão de caracteres maiúsculos

      if (regex.test(password.value)) {
        return true;
      }
    },
    numero: function () {
        let regex = /^(?=.*[0-9]).+$/; // Padrão de caracteres numéricos
  
        if (regex.test(password.value)) {
          return true;
        }
      },
    especial: function () {
      let regex = /^(?=.*[@!#$%^&*()/\\]).+$/; // Padrão de caracteres especiais

      if (regex.test(password.value)) {
        return true;
      }
    }
  };

  // Monitora a ação de digitar no campo de senha
  password.addEventListener("keyup", function () {
    // Verifica se a senha tem no mínimo 8 caracters
    patternTest(pattern.charTamanho(), TextoAjuda.charTamanho);

    // Verifica se a senha tem uma letra minúscula
    patternTest(pattern.minusculo(), TextoAjuda.minusculo);

    // Verifica se a senha tem uma letra maiúscula
    patternTest(pattern.maiusculo(), TextoAjuda.maiusculo);

    // Verifica se a senha tem um número
    patternTest(pattern.numero(), TextoAjuda.numero);

    // Verifica se a senha tem um caracter especial
    patternTest(pattern.especial(), TextoAjuda.especial);

    // Verifica se todos os requisitos foram cumpridos
    if (
      hasClass(TextoAjuda.charTamanho, "valid") &&
      hasClass(TextoAjuda.minusculo, "valid") &&
      hasClass(TextoAjuda.maiusculo, "valid") &&
      hasClass(TextoAjuda.numero, "valid") &&
      hasClass(TextoAjuda.especial, "valid")
    ) {
      addClass(password.parentElement, "valid");
    } else {
      removeClass(password.parentElement, "valid");
    }
  });

  function patternTest(pattern, response) {
    if (pattern) {
      addClass(response, "valid");
    } else {
      removeClass(response, "valid");
    }
  }

  function addClass(el, className) {
    if (el.classList) {
      el.classList.add(className);
    } else {
      el.className += " " + className;
    }
  }

  function removeClass(el, className) {
    if (el.classList) el.classList.remove(className);
    else
      el.className = el.className.replace(
        new RegExp(
          "(^|\\b)" + className.split(" ").join("|") + "(\\b|$)",
          "gi"
        ),
        " "
      );
  }

  function hasClass(el, className) {
    if (el.classList) {
      console.log(el.classList);
      return el.classList.contains(className);
    } else {
      new RegExp("(^| )" + className + "( |$)", "gi").test(el.className);
    }
  }
})();