
# Responsive Cards

Responsive Cards using HTML and CSS.<br />
This project was made for a youtube tutorial.<br /><br/>
**Youtube link: https://youtu.be/_-3nHZHkn4M**
### Web Version
<img src="https://i.imgur.com/nxf5JAi.png" alt="Web Version"/>

### Mobile Version
<img src="https://i.imgur.com/GfFl7Pt.png" alt="Mobile Version" width="300"/>

## 🚀 Starting

To start the project, just open the file `index.html` in your preferred browser.

---
##### Coded with love by Giovanna Moeller ♥️
