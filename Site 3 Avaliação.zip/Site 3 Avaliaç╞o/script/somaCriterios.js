$(function () {

    var valorCalculado = 0;

    $(".pontos-blue").each(function () {
        valorCalculado += parseInt($(this).text());
    });
    $("#total-blue").text(valorCalculado);

});

$(function () {

    var valorCalculado = 0;

    $(".pontos-kron").each(function () {
        valorCalculado += parseInt($(this).text());
    });
    $("#total-kron").text(valorCalculado);

});

$(function () {

    var valorCalculado = 0;

    $(".pontos-join").each(function () {
        valorCalculado += parseInt($(this).text());
    });
    $("#total-join").text(valorCalculado);

});

$(function () {

    var valorCalculado = 0;

    $(".pontos-stefanini").each(function () {
        valorCalculado += parseInt($(this).text());
    });
    $("#total-stefanini").text(valorCalculado);

});

$(function () {

    var valorCalculado = 0;

    $(".pontos-wise").each(function () {
        valorCalculado += parseInt($(this).text());
    });
    $("#total-wise").text(valorCalculado);

});


